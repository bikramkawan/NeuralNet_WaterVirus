
// Author URL: http://bikramkawan.com.np
// Email : bikramkawan@gmail.com
// Version: 18.03.2016

 

 var cleaningid ;
   var xval=[];
var yval=[]; 
var rawvalue=[];
var cleanvalue=[];
var timeseries=[];
var dateseries=[]; 

  $(document).ready(function(){

  

$('#featureattr').change(function() {
    attribute1=($(this).val());
 featureattr = $(this).children(":selected").attr("id");
   //alert("Y Correction"+featureattr);


});
  


///Plot for Heading Before Correction and After Correction
$('#termotol').click(function () {
 

  $.getJSON('cleandata.json', function (data) {
   //console.log(data);
    //console.log((parseFloat(data.cleandata.rawdata[7][0])))
     
    // console.log(((data.cleandata.dateseries[0].Day)++))

  //console.log(data.cleandata.rawdata.length); //console.log("'"+year+"-"+month+"-"+day+"'");
for (var i = 0; i <data.cleandata.rawdata.length; i++) {

  rawvalue.push([]);
  cleanvalue.push([]);

    for (var j = 0; j <data.cleandata.rawdata[0].length; j++) { 
   // console.log((parseFloat(data.cleandata.rawdata[i][j])))

  rawvalue[i].push(parseFloat(data.cleandata.rawdata[i][j]));
  cleanvalue[i].push(parseFloat(data.cleandata.cleandata[i][j]));
 
}
   
};
for (var j = 0; j <data.cleandata.dateseries.length; j++) { 

 
    day=data.cleandata.dateseries[j].Day;
     month=data.cleandata.dateseries[j].Month;
     year= data.cleandata.dateseries[j].Year;
    dateseries.push(year+"-"+month+"-"+day);
};


TESTER = document.getElementById('rawdatadiv');

data ={
    x: dateseries,
    y: rawvalue[featureattr],
     name: "Termotol with Missing Data",
     mode: 'lines'

 
   };


    data1 ={
    x: dateseries,
    y: cleanvalue[featureattr],
    mode: 'lines',

    line: {
     dash: 'dot', 
    color: 'rgb(255, 0, 0)',
    width:2
  },
    name: "Termotol after filling Missing Data"};

var layout = {
   showlegend: true,
  legend: {
    x: 0.5,
    y: 1
  },

  font: {
   
    size: 25
  },
  xaxis: {
    title: 'Timeseries'
   
  },
  yaxis: {
    title: 'Termotol Koliforme (cfu/100 ml)',
 
  
  },
  
    width :1000,
    height:800,
  margin: { t: 0 }
  
  
  
};   

var dataset=[data,data1];
console.log(data1);
Plotly.newPlot(TESTER, dataset,layout);



  });
});







});



