
a= 'mod3.json'
tmp=loadjson(['examples' filesep 'mod3.json']);

json=savejson('',matname,'filename.json')