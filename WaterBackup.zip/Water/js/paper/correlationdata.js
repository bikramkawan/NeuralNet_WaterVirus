
// Author URL: http://bikramkawan.com.np
// Email : bikramkawan@gmail.com
// Version: 18.03.2016



var Rval=[];
var Pval=[];
var corval_Y=[];
var ylabel;
var corrindex_X=[];
var Rval1_y=[],Pval1_y=[],Rval2_y=[],Pval2_y=[],Rval3_y=[],Pval3_y=[],Rval4_y=[],Pval4_y=[],Rval5_y=[],Pval5_y=[];
var Rval6_y=[],Pval6_y=[],Rval7_y=[],Pval7_y=[],Rval8_y=[],Pval8_y=[],Rval9_y=[],Pval9_y=[],Rval10_y=[],Pval10_y=[];
var yval2=[];
var xvalues=["Koliforme Bakterier[cfu/100 ml]","Termotol Koliforme[cfu/100 ml]","Kimtall v/22°C[cfu/ml]","Fargetall[mgPt/l]","Turbiditet[FNU]","pH","Konduktivitet/Led.ev[mS/m]"]
var index_xvalue=[];

$(document).ready(function(){


//Block for Generating JSON Data
   $(document).ajaxStart(function(){
        $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $("#wait").css("display", "none");
    });

  $('#generatecorrdata').click(function() {



  $.ajax({
    
    url: 'Matlab/correlation/generatecorrdata.php',
   data:{ cleaningid: cleaningid},
    method:'GET',
   
    success: function (data) {
      // hide the "loading..." message
      alert("Correlation Process was successfully done by Matlab")
	
  
    },
    error: function (err) {
      console.log('Error', err);
      if (err.status === 0) {
        alert('Failed to load json.\nPlease run this example on a server.');
      }
      else {
        alert('Failed to load json.');
      }
    }
  });

  });

//Block For preparation for selecting variables to show correlation data.

$('#corrx').change(function() {
    attribute=($(this).val());

 corval_Y = $(this).children(":selected").attr("id");




});


//Block For Plot Bar Chart

$('#corrbar').click(function () {


  //Block for Muliple Parameters Filterd
  $('#multiple :selected').each(function(i, sel){ 

   //console.log( $(sel).val()); 
    corrindex_X.push(parseFloat($(sel).val()));


});



   $.ajax({
    url:'Matlab/correlation/corrdata.json',
    type:'HEAD',
    error: function()
    {
        //file not exists
    alert("Matlab is processing Correlation Data");
    },
    success: function()
    {
         alert("Matlab successfully generates Correlation Data");
    }
});
 //Plot for Bar Chart Continues
  $.getJSON('Matlab/correlation/corrdata.json', function (data) {
  
 console.log(data);
   // console.log(data.corrdata.R[0][9])

   
for (var i = 0; i <data.corrdata.P.length; i++) {
    
  for (var j = 0; j <data.corrdata.P.length; j++)
  {


  Rval.push((data.corrdata.R[i][j]));
  Pval.push((data.corrdata.P[i][j]));


   }
 // timeseries.push(parseFloat(data.heading[i][2]));
//console.log(Rval);
  
};

//console.log(Rval.length);
//Data splitted for all attributes
//1.  surge_vel[m/s], 
// 2.  sway_vel[m/s],
// 3.  yaw_vel[deg/s], 
// 4.  roll_vel[deg/s], 
// 5.  pitch_vel[deg/s], 
// 6.  pos_x[m],   (Position East)
// 7.   pos_y[m],   (Position North)
// 8.  heading[deg], 
// 9.  roll[deg], 
// 10. pitch[deg],

//Slice Value
s0=0;s1=7;s2=s1*2;s3=s1*3;s4=s1*4;s5=s1*5;s6=s1*6;s7=s1*7;


Rval1= Rval.slice(s0,s1);                 Pval1= Pval.slice(s0,s1);
Rval2= Rval.slice(s1,s2);                 Pval2= Pval.slice(s1,s2);
Rval3= Rval.slice(s2,s3);                 Pval3= Pval.slice(s2,s3);
Rval4= Rval.slice(s3,s4);                 Pval4= Pval.slice(s3,s4);               
Rval5= Rval.slice(s4,s5);                 Pval5= Pval.slice(s4,s5);
Rval6= Rval.slice(s5,s6);                 Pval6= Pval.slice(s5,s6);
Rval7= Rval.slice(s6,s7);                 Pval7= Pval.slice(s6,s7);


console.log(Rval1[0]);





 //Making Ready for Data for Plot Function 

 //If Case 1 = Surge Velocity 
if(corval_Y==1) { 

    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

    for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval1_y.push(Rval1[corrindex_X[k]]); 
    Pval1_y.push(Pval1[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  }

 
  plotdatay1 = Rval1_y;      plotdatay2 = Pval1_y;  
  
    ylabel = xvalues[0]; 
  }

// Case 2 = Sway Velocity 
if(corval_Y==2) 
{ 
    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval2_y.push(Rval2[corrindex_X[k]]); 
    Pval2_y.push(Pval2[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval2_y;      plotdatay2 = Pval2_y;

   ylabel = xvalues[1];  

}

// Case 3 = Yaw Velocity 
if(corval_Y==3) 
{ 
    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval3_y.push(Rval3[corrindex_X[k]]); 
    Pval3_y.push(Pval3[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval3_y;      plotdatay2 = Pval3_y; 

     ylabel = xvalues[2];  

}
 

 // Case 4 = Roll  Velocity 
if(corval_Y==4) 
{ 
   var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval4_y.push(Rval4[corrindex_X[k]]); 
    Pval4_y.push(Pval4[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval4_y;      plotdatay2 = Pval4_y; 

     ylabel = xvalues[3];  

}  


 // Case 5 = Pitch Velocity 
if(corval_Y==5) 
{ 
    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval5_y.push(Rval5[corrindex_X[k]]); 
    Pval5_y.push(Pval5[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval5_y;      plotdatay2 = Pval5_y; 

     ylabel = xvalues[4];  

}   

 // Case 6 = Position East
if(corval_Y==6) 
{ 
    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval6_y.push(Rval6[corrindex_X[k]]); 
    Pval6_y.push(Pval6[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval6_y;      plotdatay2 = Pval6_y; 

     ylabel = xvalues[5];  

}   

 // Case 7 = Position North
if(corval_Y==7) 
{ 
    var plotdatay1=[],plotdatay2=[],index_xvalue=[];

  for (var k = 0; k <corrindex_X.length; k++)
  {
    Rval7_y.push(Rval7[corrindex_X[k]]); 
    Pval7_y.push(Pval7[corrindex_X[k]]); 
    index_xvalue.push(xvalues[corrindex_X[k]]);  
  }
  plotdatay1 = Rval7_y;      plotdatay2 = Pval7_y; 

   ylabel = xvalues[6];  

}   





 




console.log(plotdatay1);
console.log(plotdatay2);
//Plot Function Data Starts here
var R = {
  x: index_xvalue,
  y: plotdatay1,
  name: 'R',
  type: 'bar'
};

var P = {
x: index_xvalue,
  y: plotdatay2,
  name: 'P',
  type: 'bar'
};

var data = [R, P];

var layout = {yaxis: 
              {title: ylabel},
              barmode: 'group'};


Plotly.newPlot('corrchartarea', data,layout);


  });

});






    });
